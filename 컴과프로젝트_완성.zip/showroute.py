from Dijkstraalgorithm import dijkstra
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from sources import translate

def showroute():#list로 경로 반환
    with open('save.txt','r',encoding='utf-8') as f:
        lst=[i.strip() for i in f.readlines()]
        Bool= True if lst[2]==1 else False
        start=f'{translate(lst[0])[0]}_{translate(lst[0])[1]}층'
        end=f'{translate(lst[1])[0]}_{translate(lst[1])[1]}층'

    route=dijkstra(Bool,start,end)
    navigation=Image.open('sshsmap.jpg')
    navigation_np=np.array(navigation)
    plt.imshow(navigation)
    for i in range(len(route)-1):
        if route[i].split('_')[0]!=route[i+1].split('_')[0]:
            plt.imshow(np.array(Image.open(f'{route[i]}_{route[i+1]}.png')))
    plt.axis('off')
    plt.show()  