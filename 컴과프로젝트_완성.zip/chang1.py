from tkinter import *
from search_popup import open_newchang1, open_newchang2
import pygame
import sys

# 효과음 초기화
pygame.mixer.init()
effect = pygame.mixer.Sound('open.mp3')

def chang1():
    chang = Tk()
    chang.title('출발·도착지 입력 - Ddalbae')
    chang.geometry('460x270')
    chang.configure(bg="#F5F7FB")
    chang.option_add('*Font', '맑은고딕 15')
    try:
        chang.iconbitmap('favicon.ico')
    except Exception:
        pass
    chang.protocol("WM_DELETE_WINDOW", sys.exit)

    # 상단 타이틀
    title = Label(chang, text='출발·도착지 정보 입력', bg='#F5F7FB', fg='#3867d6', font=('맑은고딕', 22, 'bold'))
    title.grid(row=0, column=0, columnspan=3, pady=(18, 10))

    # 출발 위치
    lab1 = Label(chang, text='출발 지점', width=10, anchor='e', bg='#F5F7FB')
    lab1.grid(row=1, column=0, padx=12, pady=12)
    ent_start = Entry(chang, width=19, state='readonly', font=('맑은고딕', 15))
    ent_start.grid(row=1, column=1, padx=(0, 8))
    btn_search_start = Button(
        chang, text='검색', width=6,
        command=lambda: [effect.play(), open_newchang1(chang, ent_start)],
        bg='#60a3bc', fg='white', activebackground='#3c6382', relief='flat', bd=0, cursor='hand2'
    )
    btn_search_start.grid(row=1, column=2, padx=5)

    # 도착 위치
    lab2 = Label(chang, text='도착 지점', width=10, anchor='e', bg='#F5F7FB')
    lab2.grid(row=2, column=0, padx=12, pady=12)
    ent_end = Entry(chang, width=19, state='readonly', font=('맑은고딕', 15))
    ent_end.grid(row=2, column=1, padx=(0, 8))
    btn_search_end = Button(
        chang, text='검색', width=6,
        command=lambda: [effect.play(), open_newchang2(chang, ent_end)],
        bg='#60a3bc', fg='white', activebackground='#3c6382', relief='flat', bd=0, cursor='hand2'
    )
    btn_search_end.grid(row=2, column=2, padx=5)

    # 체크박스
    rain_var = IntVar()
    chk = Checkbutton(chang, text='비가 오나요?', variable=rain_var, bg='#F5F7FB', font=('맑은고딕', 13))
    chk.grid(row=3, column=0, columnspan=3, pady=(10, 0))

    # 확인 버튼
    def on_click():
        try:
            start = ent_start.get()
            end = ent_end.get()
            rain = rain_var.get()
            if not start or not end:
                raise ValueError("입력값이 비어 있습니다.")

            effect.play()  # 효과음 재생
            with open('save.txt', 'w', encoding='utf-8') as f:
                f.write(start + '\n')
                f.write(end + '\n')
                f.write(str(rain) + '\n')
            chang.destroy()

        except ValueError:
            # 작은 안내 창 띄우기
            popup = Toplevel(chang)
            popup.geometry('400x70')
            popup.title("알림")
            popup.resizable(False, False)
            popup.configure(bg="#fff")
            Label(popup, text='입력이 안 되었습니다', bg='#fff', font=('맑은고딕', 14)).pack(pady=(13, 0))

            def close_popup():
                popup.destroy()

        btn = Button(popup, text='닫기', command=close_popup, bg='#3867d6', fg='white',
                     font=('맑은고딕', 10), width=6, height=1, relief='flat', bd=0, cursor='hand2')
        btn.place(relx=1.0, rely=1.0, anchor='se', x=-10, y=-10)

    bt = Button(
        chang, text='확인', command=on_click,
        bg='#3867d6', fg='white', font=('맑은고딕', 16, 'bold'), width=12, height=1,
        relief='flat', bd=0, cursor='hand2', activebackground='#27408B'
    )
    bt.grid(row=4, column=0, columnspan=3, pady=(24, 0))

    chang.mainloop()