import tkinter as tk
from searchengine import suggest
from sources import locations
import pygame

# 효과음 초기화 (이 파일 import될 때 한 번만)
pygame.mixer.init()
effect = pygame.mixer.Sound('close.mp3')

def open_newchang1(root, entry):
    find = tk.Toplevel(root)
    find.title("출발지 검색")
    find.configure(bg="#F5F7FB")
    find.geometry('430x260')
    try:
        find.iconbitmap('favicon.ico')
    except Exception:
        pass

    font1 = ('맑은고딕', 15)

    tk.Label(find, text="출발지 검색", bg='#F5F7FB', fg='#3867d6', font=('맑은고딕', 18, 'bold')).pack(pady=(12,5))

    entry_var = tk.StringVar()
    entry_field = tk.Entry(find, textvariable=entry_var, width=22, font=font1)
    entry_field.pack(pady=7)

    listbox = tk.Listbox(find, width=28, height=6, font=font1, relief='groove', bd=1)
    listbox.pack(pady=7)

    # 자동완성
    def on_entry_change(*args):
        value = entry_var.get()
        results = suggest(value, locations)
        listbox.delete(0, tk.END)
        for item in results:
            listbox.insert(tk.END, item)

    entry_var.trace_add('write', on_entry_change)

    # 더블 클릭으로 값 선택 (효과음 재생)
    def on_select(event):
        selected = listbox.curselection()
        if selected:
            effect.play()
            value = listbox.get(selected[0])
            entry.config(state='normal')
            entry.delete(0, tk.END)
            entry.insert(0, value)
            entry.config(state='readonly')
            find.destroy()

    listbox.bind('<Double-Button-1>', on_select)
    entry_field.focus_set()

def open_newchang2(root, entry):
    find = tk.Toplevel(root)
    find.title("도착지 검색")
    find.configure(bg="#F5F7FB")
    find.geometry('430x260')
    try:
        find.iconbitmap('favicon.ico')
    except Exception:
        pass

    font1 = ('맑은고딕', 15)

    tk.Label(find, text="도착지 검색", bg='#F5F7FB', fg='#3867d6', font=('맑은고딕', 18, 'bold')).pack(pady=(12,5))

    entry_var = tk.StringVar()
    entry_field = tk.Entry(find, textvariable=entry_var, width=22, font=font1)
    entry_field.pack(pady=7)

    listbox = tk.Listbox(find, width=28, height=6, font=font1, relief='groove', bd=1)
    listbox.pack(pady=7)

    def on_entry_change(*args):
        value = entry_var.get()
        results = suggest(value, locations)
        listbox.delete(0, tk.END)
        for item in results:
            listbox.insert(tk.END, item)

    entry_var.trace_add('write', on_entry_change)

    # 더블 클릭으로 값 선택 (효과음 재생)
    def on_select(event):
        selected = listbox.curselection()
        if selected:
            effect.play()
            value = listbox.get(selected[0])
            entry.config(state='normal')
            entry.delete(0, tk.END)
            entry.insert(0, value)
            entry.config(state='readonly')
            find.destroy()

    listbox.bind('<Double-Button-1>', on_select)
    entry_field.focus_set()