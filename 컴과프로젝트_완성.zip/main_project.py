import threading
import time
import pygame
from search_popup import open_newchang1, open_newchang2
from chang1 import chang1
from searchengine import suggest
from chang2 import chang2
from Dijkstraalgorithm import dijkstra
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from sources import translate
from showroute import showroute
def play_music():
    pygame.mixer.init()
    pygame.mixer.music.load('bgm.mp3')
    pygame.mixer.music.play(-1)  # -1 = 무한반복
    while pygame.mixer.music.get_busy():
        time.sleep(1)
if __name__ == "__main__":
    music_thread = threading.Thread(target=play_music, daemon=True)
    music_thread.start()
    try:
        while True:
            chang1()
            action = chang2()
            showroute()  # ✅ 항상 실행됨

            if action == "continue":
                continue  # 다시 chang1()부터
            else:
                break  # 프로그램 종료

    finally:
        pygame.mixer.music.stop()
        pygame.mixer.quit()

