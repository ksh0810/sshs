import pandas as pd
from sources import stairs

# 1. 엑셀 파일 불러오기
df = pd.read_excel("buildingstairs.xlsx")
df_time = pd.read_excel("buildingbuildingtime.xlsx", header=1, index_col=0)



# 3. 초기 그래프 구성
graph = {}

def parse_multi_entries(start_bld, end_bld, c_str, d_str, e_str):
    nodes = {}
    try:
        c_vals = list(map(str.strip, str(c_str).split(',')))
        d_vals = list(map(str.strip, str(d_str).split(',')))
        e_vals = list(map(str.strip, str(e_str).split(',')))

        if len(c_vals) == len(d_vals) == len(e_vals):
            for c, d, e in zip(c_vals, d_vals, e_vals):
                if c != '0' and d != '0' and e != '0':
                    start_node = f"{start_bld}_{c}층"
                    end_node = f"{end_bld}_{d}층"
                    nodes.setdefault(start_node, {})[end_node] = int(e)
    except:
        pass
    return nodes

# 4. 외부 연결 정보 파싱
for _, row in df.iterrows():
    start_building, end_building = row[0], row[1]
    c, d, e = row[2], row[3], row[4]

    if all(isinstance(val, str) and ',' in val for val in [str(c), str(d), str(e)]):
        parsed = parse_multi_entries(start_building, end_building, c, d, e)
        for s_node, targets in parsed.items():
            graph.setdefault(s_node, {}).update(targets)
    elif all(val != 0 for val in [c, d, e]):
        start_node = f"{start_building}_{c}층"
        end_node = f"{end_building}_{d}층"
        graph.setdefault(start_node, {})[end_node] = e

# 5. 건물 내부 층 간 이동 추가
for building, max_floor in stairs.items():
    if building not in df_time.index:
        continue

    time_per_floor = df_time.loc[building].values[0]

    for i in range(1, max_floor + 1):
        for j in range(1, max_floor + 1):
            if i != j:
                from_node = f"{building}_{i}층"
                to_node = f"{building}_{j}층"
                cost = abs(i - j) * time_per_floor + 1
                graph.setdefault(from_node, {})[to_node] = cost

# 6. 창의인재관_2.5층 처리
special_node = "창의인재관_2.5층"
time_per_floor = df_time.loc['창의인재관'].values[0]

for i in range(1, stairs['창의인재관'] + 1):
    from_node = f"창의인재관_{i}층"
    cost = abs(2.5 - i) * time_per_floor + 1
    graph.setdefault(from_node, {})[special_node] = cost
    graph.setdefault(special_node, {})[from_node] = cost
updated_graph = {}

for node, edges in graph.items():
    new_node = node.replace("창의인재관_2.5층", "창의인재관_2.50층")
    new_edges = {}
    for target, cost in edges.items():
        new_target = target.replace("창의인재관_2.5층", "창의인재관_2.50층")
        new_edges[new_target] = cost
    updated_graph[new_node] = new_edges

# 이제 updated_graph를 사용하시면 됩니다
graph = updated_graph
