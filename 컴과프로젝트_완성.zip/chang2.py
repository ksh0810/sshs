
import tkinter as tk
from tkinter import font
import sys
def chang2():
    result = {'action': None}
    win = tk.Tk()
    win.title("안내 및 종료 - Ddalbae")
    win.configure(bg="#F5F7FB")

    try:
        win.iconbitmap('favicon.ico')
    except Exception:
        pass

    # ✅ 창 닫기(X) 눌렀을 때는 창만 닫고 종료하지 않음
    def on_close():
        result['action'] = "exit"
        win.destroy()

    win.protocol("WM_DELETE_WINDOW", on_close)

    # 버튼 스타일
    btn_style = {
        'font': ('맑은 고딕', 16),
        'bg': '#60a3bc',
        'fg': 'white',
        'relief': 'flat',
        'activebackground': '#3c6382',
        'bd': 0,
        'width': 14,
        'height': 2,
        'cursor': 'hand2'
    }

    # "돌아가기" → 창만 닫고 계속 진행
    def on_return():
        result['action'] = "continue"
        win.destroy()

    # "프로그램 닫기" → 창 닫고 종료
    def on_exit():
        result['action'] = "exit"
        win.destroy()

    # 라벨
    label = tk.Label(win, text="입력이 완료되었습니다!", font=('맑은 고딕', 22, 'bold'), bg="#F5F7FB", fg="#3867d6")
    label.pack(pady=54)

    # 버튼들
    button = tk.Button(win, text="돌아가기", command=on_return, **btn_style)
    button.place(relx=1.0, rely=1.0, anchor="se", x=-40, y=-40)

    button_quit = tk.Button(win, text="프로그램 닫기", command=on_exit, **btn_style)
    button_quit.place(relx=0.0, rely=1.0, anchor="sw", x=40, y=-40)

    win.mainloop()
    return result['action']
